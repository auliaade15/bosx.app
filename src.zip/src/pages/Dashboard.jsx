import React from "react";

const Dashboard = () => {
  return (
    <div className="font-sans min-h-screen bg-[#C2DDE8]">
      {/* Navbar */}
      <header className="bg-[#262626] text-white py-4 px-8 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-green-500 rounded-sm"></div>
          <h1 className="text-lg font-bold">Skupy Digital Printing</h1>
        </div>

        <nav className="flex gap-8 text-sm font-semibold">
          <a href="#" className="text-teal-400">
            HOME
          </a>
          <a href="#">PRODUCTS</a>
          <a href="#">COLLECTION</a>
          <a href="#">PAGES</a>
          <a href="#">ABOUT US</a>
          <a href="#">CONTACT US</a>
        </nav>

        <div className="flex items-center gap-4 text-lg">
          <button className="hover:text-teal-400 transition">🛒</button>
          <button className="hover:text-teal-400 transition">🔍</button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="flex flex-col md:flex-row justify-between items-center px-10 md:px-20 py-16 md:py-24">
        {/* Text Content */}
        <div className="max-w-lg">
          <p className="uppercase text-sm font-semibold text-gray-700 mb-3">
            New Arrivals
          </p>
          <h1 className="text-5xl md:text-6xl font-extrabold leading-tight text-black">
            NEW STYLE
            <br />
            <span className="text-[#3B7C8E] font-normal">FOR LAMP</span>
          </h1>
          <p className="mt-6 text-gray-700 italic">
            Claritas est etiam processus dynamicus, qui sequitur mutationem
            consuetudium lectorum.
          </p>
          <button className="mt-8 px-6 py-3 border-2 border-black text-black font-semibold rounded hover:bg-black hover:text-white transition">
            Shop Now
          </button>
        </div>

        {/* Product Image */}
        <div className="mt-12 md:mt-0 md:w-1/2 flex justify-center">
          <img
            src="https://cdn.pixabay.com/photo/2017/05/05/22/44/lamp-2293661_1280.png"
            alt="Lamp"
            className="w-80 md:w-[450px] object-contain"
          />
        </div>
      </section>
    </div>
  );
};

export default Dashboard;

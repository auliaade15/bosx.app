import { createRoot } from "react-dom/client";
import FormPemesananSupermarket from "./FormPemesananSupermarket";
import "./tailwind.css";

createRoot(document.getElementById("root")).render(
  <div>
    <FormPemesananSupermarket />
  </div>
);

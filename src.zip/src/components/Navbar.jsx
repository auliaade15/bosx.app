// import { NavLink } from "react-router-dom";

// export default function Navbar() {
//   const links = [
//     { name: "Home", path: "/" },
//     { name: "About", path: "/about" },
//     { name: "Services", path: "/services" },
//     { name: "Projects", path: "/projects" },
//     { name: "Contact", path: "/contact" },
//   ];

//   return (
//     <header className="bg-white shadow-md">
//       <div className="container mx-auto px-6 py-4 flex items-center justify-between">
//         <div className="flex items-center">
//           <img src="/logo.png" alt="Logo" className="w-12 h-12 mr-3" />
//           <span className="text-xl font-bold text-blue-700">Thewa Global</span>
//         </div>
//         <nav className="space-x-6">
//           {links.map((link) => (
//             <NavLink
//               key={link.path}
//               to={link.path}
//               className={({ isActive }) =>
//                 isActive
//                   ? "text-blue-700 font-semibold"
//                   : "text-gray-600 hover:text-blue-700"
//               }
//             >
//               {link.name}
//             </NavLink>
//           ))}
//         </nav>
//       </div>
//     </header>
//   );
// }

import React from "react";

const Navbar = () => {
  return (
    <div className="bg-black text-white">
      <div className="container mx-auto flex justify-between items-center py-4 px-4">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-teal-400 rounded-sm"></div>
          <span className="font-bold text-lg">Eren</span>
        </div>
        <nav className="flex gap-6 text-sm">
          <a href="#" className="hover:text-teal-400">Home</a>
          <a href="#" className="hover:text-teal-400">Products</a>
          <a href="#" className="hover:text-teal-400">Collection</a>
          <a href="#" className="hover:text-teal-400">Pages</a>
          <a href="#" className="hover:text-teal-400">About Us</a>
          <a href="#" className="hover:text-teal-400">Contact Us</a>
        </nav>
        <div className="flex items-center gap-4">
          <button className="hover:text-teal-400">🛒</button>
          <button className="hover:text-teal-400">🔍</button>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
